WASD, ctrl, space - movement
  mouse - camera movement
  tab - change camera mode
  f1 - pause
  esc - quit
Goal: swim to the other side of the aquarium, dodge the transparent bubbles, catch the glowing bubbles for more points.
When you reach the other side, the difficulty will rise. Now swim back.
Each bubble is worth a number of points the same as the difficulty level. Beating a level gives you 10 bubbles worth of points.